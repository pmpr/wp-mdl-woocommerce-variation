<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684014684488             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceVariation; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { }
