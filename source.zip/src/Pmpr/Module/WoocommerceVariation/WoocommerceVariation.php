<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668708767dbd9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceVariation; use Pmpr\Common\Foundation\Container\ComponentInitiator; class WoocommerceVariation extends ComponentInitiator { public function register() { $this->gkieogwukagigisy(__DIR__, [self::qescuiwgsyuikume => static function () { return __("\x57\x6f\157\x63\x6f\x6d\155\145\x72\143\145\40\126\141\x72\x69\x61\x74\151\157\x6e", PR__MDL__WOOCOMMERCE_VARIATION); }, self::wuowaiyouwecckaw => false]); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\146\x74\145\x72\137\x73\145\164\x75\160\137\x74\150\x65\155\145", [$this, "\153\147\x6b\155\167\165\x63\x6d\x6b\143\161\x61\x6b\x73\x6d\x6f"]); } public function kgkmwucmkcqaksmo() { if (!($this->caokeucsksukesyo()->wikusamwomuogoau()->ggocakcisguuokai() && $this->uwkmaywceaaaigwo()->aqasygcsqysmmyke()->kmymkocwcawgeccm())) { goto cecuyayqoioasumi; } Product::symcgieuakksimmu(); $this->enqueue(); cecuyayqoioasumi: } public function enqueue() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->owygwqwawqoiusis("\166\141\162\151\x61\x74\151\157\156", $eygsasmqycagyayw->get("\146\162\157\156\x74\56\152\x73"))->simswskycwagoeqy()); } }
