<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a8e9c72ba             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceVariation; use Pmpr\Common\Foundation\Container\ComponentInitiator; class WoocommerceVariation extends ComponentInitiator { public function register() { $this->gkieogwukagigisy(__DIR__, [self::qescuiwgsyuikume => static function () { return __("\x57\157\157\x63\157\x6d\155\x65\162\143\145\40\126\141\x72\151\x61\164\151\157\156", PR__MDL__WOOCOMMERCE_VARIATION); }, self::wuowaiyouwecckaw => false]); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\146\x74\x65\162\137\x73\145\164\x75\x70\x5f\x74\150\x65\x6d\145", [$this, "\153\x67\153\155\x77\x75\x63\x6d\153\x63\161\x61\x6b\163\155\x6f"]); } public function kgkmwucmkcqaksmo() { if (!($this->caokeucsksukesyo()->wikusamwomuogoau()->ggocakcisguuokai() && $this->uwkmaywceaaaigwo()->aqasygcsqysmmyke()->kmymkocwcawgeccm())) { goto cecuyayqoioasumi; } Product::symcgieuakksimmu(); $this->enqueue(); cecuyayqoioasumi: } public function enqueue() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->owygwqwawqoiusis("\166\x61\162\x69\x61\164\151\157\156", $eygsasmqycagyayw->get("\x66\162\157\x6e\164\x2e\152\x73"))->simswskycwagoeqy()); } }
