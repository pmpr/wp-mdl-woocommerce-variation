<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d291d28f67             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceVariation; use Pmpr\Common\Foundation\Container\ComponentInitiator; class WoocommerceVariation extends ComponentInitiator { public function register() { $this->gkieogwukagigisy(__DIR__, [self::qescuiwgsyuikume => static function () { return __("\127\157\157\x63\157\x6d\x6d\x65\162\x63\145\x20\x56\x61\x72\151\x61\164\151\x6f\x6e", PR__MDL__WOOCOMMERCE_VARIATION); }, self::wuowaiyouwecckaw => false]); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\146\x74\145\x72\137\163\x65\164\165\x70\137\x74\x68\x65\155\x65", [$this, "\153\x67\153\155\167\165\143\155\x6b\143\161\141\x6b\x73\x6d\157"]); } public function kgkmwucmkcqaksmo() { if (!($this->caokeucsksukesyo()->wikusamwomuogoau()->ggocakcisguuokai() && $this->uwkmaywceaaaigwo()->aqasygcsqysmmyke()->kmymkocwcawgeccm())) { goto cecuyayqoioasumi; } Product::symcgieuakksimmu(); $this->enqueue(); cecuyayqoioasumi: } public function enqueue() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->owygwqwawqoiusis("\x76\141\162\151\x61\x74\x69\157\x6e", $eygsasmqycagyayw->get("\146\162\157\x6e\164\x2e\x6a\x73"))->simswskycwagoeqy()); } }
