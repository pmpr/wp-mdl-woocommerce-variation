<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e427400c91             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceVariation; use Pmpr\Common\Foundation\Container\ComponentInitiator; class WoocommerceVariation extends ComponentInitiator { public function register() { $this->gkieogwukagigisy(__DIR__, [self::qescuiwgsyuikume => static function () { return __("\x57\x6f\157\x63\x6f\x6d\x6d\145\x72\143\145\x20\x56\141\x72\x69\x61\x74\151\157\156", PR__MDL__WOOCOMMERCE_VARIATION); }, self::wuowaiyouwecckaw => false]); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\x66\164\145\x72\137\x73\x65\164\x75\x70\137\x74\x68\x65\x6d\145", [$this, "\153\147\x6b\155\x77\x75\143\x6d\153\143\x71\x61\153\x73\x6d\157"]); } public function kgkmwucmkcqaksmo() { if (!($this->caokeucsksukesyo()->wikusamwomuogoau()->ggocakcisguuokai() && $this->uwkmaywceaaaigwo()->aqasygcsqysmmyke()->kmymkocwcawgeccm())) { goto yiwiqaqmwiogawym; } Product::symcgieuakksimmu(); $this->enqueue(); yiwiqaqmwiogawym: } public function enqueue() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->owygwqwawqoiusis("\x76\141\x72\151\141\x74\151\157\x6e", $eygsasmqycagyayw->get("\146\x72\157\x6e\164\56\152\163"))->simswskycwagoeqy()); } }
