<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684014684488             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceVariation; use Pmpr\Common\Foundation\Container\ComponentInitiator; class WoocommerceVariation extends ComponentInitiator { public function register() { $this->gkieogwukagigisy(__DIR__, [self::qescuiwgsyuikume => static function () { return __("\127\157\157\x63\157\155\155\145\162\143\145\40\126\141\162\151\141\x74\x69\x6f\x6e", PR__MDL__WOOCOMMERCE_VARIATION); }, self::wuowaiyouwecckaw => false]); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\146\x74\x65\x72\x5f\163\145\x74\165\160\137\164\150\x65\155\x65", [$this, "\x6b\x67\x6b\155\167\x75\143\x6d\153\143\161\x61\153\163\x6d\157"]); } public function kgkmwucmkcqaksmo() { if (!($this->caokeucsksukesyo()->wikusamwomuogoau()->ggocakcisguuokai() && $this->uwkmaywceaaaigwo()->aqasygcsqysmmyke()->kmymkocwcawgeccm())) { goto cecuyayqoioasumi; } Product::symcgieuakksimmu(); $this->enqueue(); cecuyayqoioasumi: } public function enqueue() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->owygwqwawqoiusis("\166\141\x72\x69\141\164\x69\157\156", $eygsasmqycagyayw->get("\146\162\157\x6e\x74\x2e\x6a\x73"))->simswskycwagoeqy()); } }
