<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6606b50d28aff             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceVariation; use Pmpr\Common\Foundation\Container\ComponentInitiator; class WoocommerceVariation extends ComponentInitiator { public function register() { $this->gkieogwukagigisy(__DIR__, [self::qescuiwgsyuikume => static function () { return __("\127\x6f\157\x63\157\155\x6d\145\162\x63\x65\40\126\141\162\151\x61\164\151\x6f\156", PR__MDL__WOOCOMMERCE_VARIATION); }, self::wuowaiyouwecckaw => false]); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x66\164\145\x72\x5f\163\145\164\165\160\137\164\x68\145\x6d\145", [$this, "\x6b\147\x6b\155\167\165\143\155\153\143\161\141\x6b\x73\155\157"]); } public function kgkmwucmkcqaksmo() { if (!($this->caokeucsksukesyo()->wikusamwomuogoau()->ggocakcisguuokai() && $this->uwkmaywceaaaigwo()->aqasygcsqysmmyke()->kmymkocwcawgeccm())) { goto cecuyayqoioasumi; } Product::symcgieuakksimmu(); $this->enqueue(); cecuyayqoioasumi: } public function enqueue() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->owygwqwawqoiusis("\x76\x61\x72\151\141\164\x69\157\x6e", $eygsasmqycagyayw->get("\146\x72\157\x6e\164\x2e\152\163"))->simswskycwagoeqy()); } }
